const calculate = document.querySelector("#cal")
let cal = 0;


const upDown = document.querySelectorAll("#updown").forEach(
    (item,idx) => {
        const select = item.querySelector("input");
        const bid = item.querySelector("#bid");
        const pay =parseInt(item.querySelector("#pay").innerText);
        cal+= pay*select.value
        const del = item.querySelector("#bDel");
        item.querySelector("#down").addEventListener("click",() => {
            select.value--
            cal -= pay;
            calculate.value = cal;
        });

        item.querySelector("#up").addEventListener("click", () => {
            select.value++
            cal += pay;
            calculate.value = cal;
        });   
        
        del.addEventListener("click",(e)=>
        {
            
            console.log(bid.value);
        
            
            
        })
    }
)